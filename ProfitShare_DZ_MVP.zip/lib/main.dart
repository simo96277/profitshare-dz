import 'package:flutter/material.dart';

void main() {
  runApp(const ProfitShareApp());
}

class ProfitShareApp extends StatelessWidget {
  const ProfitShareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ProfitShare DZ',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        scaffoldBackgroundColor: const Color(0xFFF5F8F6),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF079455)),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int selectedIndex = 0;
  final pages = const [
    HomePage(), ProjectsPage(), PortfolioPage(), TransactionsPage(), ProfilePage()
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: pages[selectedIndex],
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: (i) => setState(() => selectedIndex = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.business_center_outlined), selectedIcon: Icon(Icons.business_center), label: 'المشاريع'),
            NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'المحفظة'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'العمليات'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: CustomScrollView(slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(children: [
              const CircleAvatar(
                radius: 24,
                backgroundColor: Color(0xFFDDF7EA),
                child: Icon(Icons.person, color: Color(0xFF079455)),
              ),
              const SizedBox(width: 12),
              const Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('مرحبًا 👋', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text('تابع استثماراتك بسهولة', style: TextStyle(color: Colors.grey)),
                ],
              )),
              IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
            ]),
          ),
        ),
        const SliverToBoxAdapter(child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20), child: PortfolioCard())),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 25, 20, 12),
          child: Row(children: [
            const Expanded(child: Text('مشاريع متاحة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
            TextButton(onPressed: () {}, child: const Text('عرض الكل')),
          ]),
        )),
        SliverToBoxAdapter(child: ProjectCard(
          project: projects[0],
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => ProjectDetailsPage(project: projects[0]))),
        )),
        SliverToBoxAdapter(child: ProjectCard(
          project: projects[1],
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => ProjectDetailsPage(project: projects[1]))),
        )),
        const SliverToBoxAdapter(child: SizedBox(height: 30)),
      ]),
    );
  }
}

class PortfolioCard extends StatelessWidget {
  const PortfolioCard({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF064E3B), Color(0xFF079455)]),
        borderRadius: BorderRadius.circular(24),
      ),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('قيمة المحفظة', style: TextStyle(color: Colors.white70)),
        SizedBox(height: 8),
        Text('560,000 دج', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
        SizedBox(height: 20),
        Row(children: [
          Expanded(child: StatItem(title: 'رأس المال', value: '500,000 دج')),
          Expanded(child: StatItem(title: 'الأرباح المحققة', value: '60,000 دج')),
        ]),
      ]),
    );
  }
}

class StatItem extends StatelessWidget {
  final String title, value;
  const StatItem({super.key, required this.title, required this.value});
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: const TextStyle(color: Colors.white70)),
      const SizedBox(height: 5),
      Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
    ],
  );
}

class Project {
  final String title, category, description;
  final double target, funded;
  final int duration;
  const Project({
    required this.title, required this.category, required this.target,
    required this.funded, required this.duration, required this.description,
  });
  double get progress => funded / target;
}

const projects = [
  Project(
    title: 'مشروع قطع غيار الدراجات',
    category: 'تجارة',
    target: 2000000,
    funded: 1250000,
    duration: 6,
    description: 'مشروع تجريبي لتوسيع مخزون قطع غيار الدراجات النارية وزيادة حجم المبيعات.',
  ),
  Project(
    title: 'مشروع مطعم وجبات سريعة',
    category: 'مطاعم',
    target: 1500000,
    funded: 740000,
    duration: 4,
    description: 'مشروع تجريبي لتوسعة مطعم للوجبات السريعة من خلال معدات ومخزون جديد.',
  ),
];

class ProjectCard extends StatelessWidget {
  final Project project;
  final VoidCallback onTap;
  const ProjectCard({super.key, required this.project, required this.onTap});

  String money(double v) => '${v.toStringAsFixed(0)} دج';

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 6, 20, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(blurRadius: 15, color: Colors.black.withOpacity(.05))],
      ),
      child: Column(children: [
        Row(children: [
          Container(
            width: 65, height: 65,
            decoration: BoxDecoration(color: const Color(0xFFE5F7EE), borderRadius: BorderRadius.circular(16)),
            child: const Icon(Icons.two_wheeler, color: Color(0xFF079455), size: 35),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(project.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 5),
            Text(project.category, style: const TextStyle(color: Colors.grey)),
          ])),
        ]),
        const SizedBox(height: 15),
        Row(children: [
          Text('${(project.progress * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF079455))),
          const SizedBox(width: 8),
          Expanded(child: LinearProgressIndicator(value: project.progress, minHeight: 7, borderRadius: BorderRadius.circular(10))),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: Text('${money(project.funded)} / ${money(project.target)}', style: const TextStyle(fontSize: 12))),
          Text('${project.duration} أشهر', style: const TextStyle(fontSize: 12)),
        ]),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: ElevatedButton(onPressed: onTap, child: const Text('عرض المشروع'))),
      ]),
    );
  }
}

class ProjectsPage extends StatelessWidget {
  const ProjectsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Column(children: [
      const Padding(padding: EdgeInsets.all(20), child: Align(
        alignment: Alignment.centerRight,
        child: Text('المشاريع', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      )),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Row(
        children: ['الكل', 'متاحة', 'مكتملة'].map((x) => Padding(
          padding: const EdgeInsets.only(left: 8), child: Chip(label: Text(x)),
        )).toList(),
      )),
      const SizedBox(height: 10),
      Expanded(child: ListView.builder(
        itemCount: projects.length,
        itemBuilder: (context, index) => ProjectCard(
          project: projects[index],
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => ProjectDetailsPage(project: projects[index]))),
        ),
      )),
    ]));
  }
}

class ProjectDetailsPage extends StatelessWidget {
  final Project project;
  const ProjectDetailsPage({super.key, required this.project});
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تفاصيل المشروع')),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              height: 190, width: double.infinity,
              decoration: BoxDecoration(color: const Color(0xFFDDF7EA), borderRadius: BorderRadius.circular(25)),
              child: const Icon(Icons.two_wheeler, size: 90, color: Color(0xFF079455)),
            ),
            const SizedBox(height: 20),
            Text(project.title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(project.category, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 25),
            _infoCard('الهدف المالي', '${project.target.toStringAsFixed(0)} دج'),
            _infoCard('المبلغ الممول', '${project.funded.toStringAsFixed(0)} دج'),
            _infoCard('مدة المشروع', '${project.duration} أشهر'),
            const SizedBox(height: 20),
            const Text('وصف المشروع', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(project.description, style: const TextStyle(height: 1.7)),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(color: const Color(0xFFFFF8E6), borderRadius: BorderRadius.circular(15)),
              child: const Text('⚠️ الاستثمار ينطوي على مخاطر. الأرباح التقديرية ليست ضمانًا للنتائج المستقبلية.', style: TextStyle(height: 1.5)),
            ),
            const SizedBox(height: 25),
            SizedBox(width: double.infinity, height: 55, child: ElevatedButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => InvestmentCalculatorPage(project: project))),
              child: const Text('احسب استثمارك', style: TextStyle(fontSize: 17)),
            )),
          ]),
        ),
      ),
    );
  }

  Widget _infoCard(String title, String value) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
    child: Row(children: [
      Expanded(child: Text(title)),
      Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
    ]),
  );
}

class InvestmentCalculatorPage extends StatefulWidget {
  final Project project;
  const InvestmentCalculatorPage({super.key, required this.project});
  @override
  State<InvestmentCalculatorPage> createState() => _InvestmentCalculatorPageState();
}

class _InvestmentCalculatorPageState extends State<InvestmentCalculatorPage> {
  final controller = TextEditingController(text: '100000');
  double estimatedProfit = 60000, total = 160000;

  void calculate() {
    final amount = double.tryParse(controller.text) ?? 0;
    setState(() {
      estimatedProfit = amount * .60; // Demo only
      total = amount + estimatedProfit;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('حاسبة الاستثمار')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.project.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 25),
            const Text('المبلغ الذي ترغب في استثماره'),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                suffixText: 'دج',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
              ),
              onChanged: (_) => calculate(),
            ),
            const SizedBox(height: 25),
            _result('رأس المال', '${double.tryParse(controller.text)?.toStringAsFixed(0) ?? '0'} دج'),
            _result('الأرباح التقديرية', '${estimatedProfit.toStringAsFixed(0)} دج'),
            _result('الإجمالي التقديري', '${total.toStringAsFixed(0)} دج'),
            const Spacer(),
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(color: const Color(0xFFFFF8E6), borderRadius: BorderRadius.circular(15)),
              child: const Text('هذه محاكاة تجريبية فقط. النسبة المعروضة ليست وعدًا أو ضمانًا للعائد.'),
            ),
            const SizedBox(height: 15),
            SizedBox(width: double.infinity, height: 55, child: ElevatedButton(
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('الاستثمار الحقيقي غير مفعّل في نسخة MVP التجريبية.'))),
              child: const Text('متابعة'),
            )),
          ]),
        ),
      ),
    );
  }

  Widget _result(String title, String value) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
    child: Row(children: [Expanded(child: Text(title)), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))]),
  );
}

class PortfolioPage extends StatelessWidget {
  const PortfolioPage({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('محفظتي', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      const PortfolioCard(),
      const SizedBox(height: 25),
      const Text('استثماراتي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      _investment('مشروع قطع غيار الدراجات', '200,000 دج', '+18,000 دج'),
      _investment('مشروع مطعم وجبات سريعة', '150,000 دج', '+15,000 دج'),
      _investment('مشروع تجاري', '150,000 دج', '+27,000 دج'),
    ]));
  }

  Widget _investment(String name, String amount, String profit) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [
      const CircleAvatar(backgroundColor: Color(0xFFDDF7EA), child: Icon(Icons.business, color: Color(0xFF079455))),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5), Text(amount),
      ])),
      Text(profit, style: const TextStyle(color: Color(0xFF079455), fontWeight: FontWeight.bold)),
    ]),
  );
}

class TransactionsPage extends StatelessWidget {
  const TransactionsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('سجل العمليات', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      _transaction(Icons.trending_up, 'أرباح مشروع', '+35,000 دج', Colors.green),
      _transaction(Icons.account_balance_wallet, 'استثمار', '-200,000 دج', Colors.red),
      _transaction(Icons.trending_up, 'أرباح', '+15,000 دج', Colors.green),
      _transaction(Icons.download, 'سحب', '-50,000 دج', Colors.red),
    ]));
  }

  Widget _transaction(IconData icon, String title, String amount, Color color) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [
      CircleAvatar(backgroundColor: color.withOpacity(.1), child: Icon(icon, color: color)),
      const SizedBox(width: 12),
      Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold))),
      Text(amount, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
    ]),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('حسابي', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const SizedBox(height: 25),
      const Center(child: CircleAvatar(
        radius: 45, backgroundColor: Color(0xFFDDF7EA),
        child: Icon(Icons.person, size: 50, color: Color(0xFF079455)),
      )),
      const SizedBox(height: 12),
      const Center(child: Text('مستخدم تجريبي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      const Center(child: Text('demo@profitshare.dz', style: TextStyle(color: Colors.grey))),
      const SizedBox(height: 30),
      _menu(Icons.person_outline, 'معلومات الحساب'),
      _menu(Icons.verified_user_outlined, 'التحقق من الهوية'),
      _menu(Icons.account_balance, 'الحساب البنكي'),
      _menu(Icons.security, 'الأمان'),
      _menu(Icons.notifications_none, 'الإشعارات'),
      _menu(Icons.language, 'اللغة'),
      _menu(Icons.help_outline, 'المساعدة'),
      const SizedBox(height: 15),
      ListTile(
        leading: const Icon(Icons.logout, color: Colors.red),
        title: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)),
        onTap: () {},
      ),
    ]));
  }

  Widget _menu(IconData icon, String title) => Card(
    elevation: 0, margin: const EdgeInsets.only(bottom: 6),
    child: ListTile(leading: Icon(icon), title: Text(title),
      trailing: const Icon(Icons.chevron_left), onTap: () {}),
  );
}
