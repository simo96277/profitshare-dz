# ProfitShare DZ — MVP

هذا المشروع عبارة عن Prototype تجريبي لواجهة تطبيق ProfitShare DZ.

## التشغيل

بعد تثبيت Flutter:

```bash
flutter pub get
flutter run
```

لبناء APK:

```bash
flutter build apk --release
```

سيظهر الملف عادة في:

`build/app/outputs/flutter-apk/release/app-release.apk`

## ملاحظة مهمة

النسخة الحالية UI/Prototype فقط:
- لا يوجد Backend.
- لا توجد حسابات حقيقية.
- لا يوجد KYC حقيقي.
- لا توجد مدفوعات أو سحوبات حقيقية.
- بيانات الأرباح والمشاريع تجريبية.
- نسبة الحاسبة الموجودة في الكود للاختبار البصري فقط وليست وعدًا أو ضمانًا للاستثمار.

قبل استقبال أموال حقيقية يجب تصميم الهيكل القانوني والتنظيمي والدفع المناسب.
